<?php

namespace app\api\controller;

use app\common\controller\Api;
use fast\Date;
use think\Db;
use fast\Calendar;


/**
 * 首页接口
 */
class Index extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];

    /**
     * 首页
     *
     */
    public function index()
    {
        $this->success('请求成功');
    }

    public function getQuestion(){
        $data=Db::table("questioncenter")
            ->where("questionType",$_GET["questionType"])
            ->where("questionSort",$_GET["questionSort"])
            ->select();
        $arr = array('code'=>1,
            'data'=>array($data));
        echo json_encode($arr);
    }

    public function addWrong(){
        $data=Db::name('solve')
            -> where('questionid',$_GET['id'])
            -> where('openid',$_GET['openid'])
            ->find();
        if($data==NULL){
            $data = ['questionid' => $_GET['id'], 'openid' => $_GET['openid'],'result'=>2];
            Db::table('solve')->insert($data);
            Db::table('userinfo')->where('openid', $_GET['openid'])->setInc('wrong');
        }
    }

    public function addRight(){
        $data=Db::name('solve')
            -> where('questionid',$_GET['id'])
            -> where('openid',$_GET['openid'])
            ->find();
        if($data==NULL){
            $data = ['questionid' => $_GET['id'], 'openid' => $_GET['openid'],'result'=>1];
            Db::table('solve')->insert($data);
            Db::table('userinfo')->where('openid', $_GET['openid'])->setInc('right');
        }
    }

    public  function  getOpenId()
    {
        $appid = "wxe8149fed6755ce70";
        $secret = "a4bf9b117a62c2d87749b7d7e8387f3f";
        $url="https://api.weixin.qq.com/sns/jscode2session?appid=".$appid."&secret=".$secret."&js_code=".$_GET['code']."&grant_type=authorization_code";
        $postUrl = $url;
        $ch = curl_init();//初始化curl
        curl_setopt($ch, CURLOPT_URL,$postUrl);//抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0);//设置header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);//要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_POST, 0);//post提交方式
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $data = curl_exec($ch);//运行curl
        curl_close($ch);
        //  var_dump($data);
        print_r($data);

    }
    public function updateUseInfo(){
        $data=[
                'openid'=>$_GET['openid'],
                'nickname' => $_GET['nickName'],
                'avatarurl' =>$_GET['avatarUrl'],
                'gender' => $_GET['gender'],
                'province' => $_GET['province'],
                'city' => $_GET['city'],
                'country' => $_GET['country'],
            ];
        Db::table('userinfo')->insert($data);

    }
    public function calendar(){
        $a=array();
        $data=Db::table('qiandao')->where('openid',$_GET['openid'])->column('date');
        if(in_array(date("Y-m-d") ,$data)){
            $flag=0;
        }else
            $flag=1;
        for($i=0;$i<count($data);$i++){
            $calendar=new Calendar();
            $calendar->date=$data[$i];
            array_push($a,$calendar);
        }
        $arr = array('code'=>1,
            'flag'=>$flag,
            'data'=>$a);
        echo json_encode($arr);
    }

    public function  qiandao(){

        $data = ['openid' => $_GET['openid'], 'date' =>date("Y-m-d") ];
        Db::table('qiandao')->insert($data);
    }

    public function  solve(){
        $data=Db::table('solve')
            ->join('questioncenter','solve.questionid = questioncenter.id')
            ->where('openid',$_GET['openid'])
            ->select();
        echo json_encode($data);
    }

    public function rank(){
        $data=Db::table('userinfo')->order('right')->select();
        echo json_encode($data);
    }

}
