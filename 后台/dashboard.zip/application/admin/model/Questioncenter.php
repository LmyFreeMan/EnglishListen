<?php

namespace app\admin\model;

use think\Model;


class Questioncenter extends Model
{

    

    

    // 表名
    protected $table = 'questioncenter';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'questionT_text',
        'questionSort_text',
        'questionType_text'
    ];
    

    
    public function getQuestiontList()
    {
        return ['A' => __('A'), 'B' => __('B')];
    }

    public function getQuestionsortList()
    {
        return ['Level 1' => __('Level 1'), 'Level 2' => __('Level 2'), 'Level 3' => __('Level 3')];
    }

    public function getQuestiontypeList()
    {
        return ['生活' => __('生活'), '儿童' => __('儿童'), '娱乐' => __('娱乐'), '趣味' => __('趣味')];
    }


    public function getQuestiontTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['questionT']) ? $data['questionT'] : '');
        $list = $this->getQuestiontList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getQuestionsortTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['questionSort']) ? $data['questionSort'] : '');
        $list = $this->getQuestionsortList();
        return isset($list[$value]) ? $list[$value] : '';
    }


    public function getQuestiontypeTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['questionType']) ? $data['questionType'] : '');
        $list = $this->getQuestiontypeList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
