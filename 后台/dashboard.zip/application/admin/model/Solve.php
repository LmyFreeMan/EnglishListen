<?php

namespace app\admin\model;

use think\Model;


class Solve extends Model
{

    

    

    // 表名
    protected $table = 'solve';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = false;

    // 定义时间戳字段名
    protected $createTime = false;
    protected $updateTime = false;
    protected $deleteTime = false;

    // 追加属性
    protected $append = [
        'result_text'
    ];
    

    
    public function getResultList()
    {
        return ['1' => __('Result 1'), '2' => __('Result 2')];
    }


    public function getResultTextAttr($value, $data)
    {
        $value = $value ? $value : (isset($data['result']) ? $data['result'] : '');
        $list = $this->getResultList();
        return isset($list[$value]) ? $list[$value] : '';
    }




}
