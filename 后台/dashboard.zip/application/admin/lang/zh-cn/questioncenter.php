<?php

return [
    'Id'              => '序号',
    'Title'           => '题目',
    'Videofile'       => '试题视频',
    'Questiona'       => 'A选项',
    'Questionb'       => 'B选项',
    'Questiont'       => '正确选项',
    'Questionsort'    => '难度级别',
    'Questiontype'    => '题目类型',
    'Questionmessage' => '字幕信息'
];
