<?php

return [
    'Openid'    => '唯一标识符',
    'Nickname'  => '昵称',
    'Avatarurl' => '图片地址',
    'Gender'    => '性别',
    'Province'  => '省份',
    'City'      => '城市',
    'Country'   => '乡村',
    'Wrong'     => '错误题目数量',
    'Right'     => '正确题目数量'
];
