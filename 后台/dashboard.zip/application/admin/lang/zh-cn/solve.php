<?php

return [
    'Id'         => '序号',
    'Questionid' => '正确id',
    'Openid'     => '唯一标识符',
    'Result'     => '答题结果：‘1'
];
