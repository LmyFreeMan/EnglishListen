<?php

return [
    'No file upload or server upload limit exceeded' => '未上传文件或超出服务器上传限制',
    'Uploaded file format is limited'                => '上传文件格式受限制',
    'Uploaded file is not a valid image'             => '上传文件不是有效的图片文件',
    'Upload successful'                              => '上传成功',
];
