define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'userinfo/index' + location.search,
                    add_url: 'userinfo/add',
                    edit_url: 'userinfo/edit',
                    del_url: 'userinfo/del',
                    multi_url: 'userinfo/multi',
                    table: 'userinfo',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'openid',
                sortName: 'openid',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'openid', title: __('Openid')},
                        {field: 'nickname', title: __('Nickname')},
                        {field: 'avatarurl', title: __('Avatarurl'), formatter: Table.api.formatter.url},
                        {field: 'gender', title: __('Gender')},
                        {field: 'province', title: __('Province')},
                        {field: 'city', title: __('City')},
                        {field: 'country', title: __('Country')},
                        {field: 'wrong', title: __('Wrong')},
                        {field: 'right', title: __('Right')},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});