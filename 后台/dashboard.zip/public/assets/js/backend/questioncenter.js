define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'questioncenter/index' + location.search,
                    add_url: 'questioncenter/add',
                    edit_url: 'questioncenter/edit',
                    del_url: 'questioncenter/del',
                    multi_url: 'questioncenter/multi',
                    table: 'questioncenter',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'title', title: __('Title')},
                        {field: 'videofile', title: __('Videofile')},
                        {field: 'questionA', title: __('Questiona')},
                        {field: 'questionB', title: __('Questionb')},
                        {field: 'questionT', title: __('Questiont'), searchList: {"A":__('A'),"B":__('B')}, formatter: Table.api.formatter.normal},
                        {field: 'questionSort', title: __('Questionsort'), searchList: {"Level 1":__('Level 1'),"Level 2":__('Level 2'),"Level 3":__('Level 3')}, formatter: Table.api.formatter.normal},
                        {field: 'questionType', title: __('Questiontype'), searchList: {"生活":__('生活'),"儿童":__('儿童'),"娱乐":__('娱乐'),"趣味":__('趣味')}, formatter: Table.api.formatter.normal},
                        {field: 'questionmessage', title: __('Questionmessage')},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});