<?php

namespace fast;

class  Calendar{
    public $date;
}
