//app.js
App({
  onLaunch: function () {
    var that=this

    var arr=[];
    for(var i=1;i<5;i++){
      var obj=new Object();
      obj.date='2020-5-'+i;
      arr.push(obj)
    }
   
    this.globalData.test=arr



    wx.login({
      success (res) {
        console.log(res.code)
        if (res.code) {
          //发起网络请求
          wx.request({
            url: that.globalData.apiUrl+'getOpenId',
            method:"GET",
            data: {
              code: res.code
            },
            success:function(e){
              console.log(e.data)
              console.log(typeof e.data)
              console.log(e.data.openid)
              that.globalData.openid=e.data.openid
            }
          })
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    })
  },
  
  globalData: {
    userInfo: null,
    questionSort:null,
    questionType:null,
    questions: [],
    test:[],
    userInfo:"",
    openid:"",
    apiUrl:"http://120.79.34.222/dashboard/public/api/Index/"
  }
})