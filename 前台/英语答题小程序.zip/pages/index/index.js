//index.js
//获取应用实例
var app = getApp().globalData

Page({
  data: {
    itemList: [{
      name: 'Level 1',
    },
    {
      name: 'Level 2',
    },
    {
      name: 'Level 3',
    }
  ]
  },

  onLoad: function () {

  },
  getUserInfo: function(e) {
   
  },
  getQuestion:function(questionSort,questionType){
    wx.request({
      url: app.apiUrl+'getQuestion',
      method:"GET",
      data:{
        "questionSort":questionSort,
        "questionType":questionType
      },
      header: {
        'content-type': 'application/json'
      },
      success:function(e){
        console.log(e.data.data[0])
        console.log(e.data.data[0].length)
        
       if(e.data.data[0].length==0){
        wx.showModal({
          title: '服务异常，请联系管理员',
          content: '',
          showCancel:false,
          success:function(res){
            if(res.confirm)
            wx.switchTab({
              url: '../../pages/index/index',
            })
          }
        })
       }
       else{
        wx.navigateTo({
          url: '../../pages/detail/detail?question='+JSON.stringify(e.data.data),
        })
       }
     
      }
    })
  },
  _showActionSheet({itemList, showCancel = false, title = '', locked=false}) {
    var that=this;
    wx.lin.showActionSheet({
      itemList: itemList,
      showCancel: showCancel,
      title: title,
      locked,
      success: function(res) {
        console.log(res.item.name)
        app.questionSort=res.item.name
        that.getQuestion(app.questionSort,app.questionType);
      },
      fail: (res) => {
        console.log(res)
      }
    })
  },
  showImagesActionSheet:function(e){

    app.questionType=e.target.dataset.title
    this._showActionSheet({ itemList: this.data.itemList})
  }
})
