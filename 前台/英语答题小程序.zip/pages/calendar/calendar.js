// pages/index/index.js
var app=getApp().globalData
Page({

  /**
   * 页面的初始数据
   */
  data: {
    selected:""
  },
  qiandao:function(e){
    console.log(e)
    var that=this;
    wx.request({
      url: app.apiUrl+'qiandao',
      method:'GET',
      data:{
        openid:app.openid
      },
      success:function(){
        that.onShow();
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) { },
  onShow:function(){

    if(app.userInfo==""){
      wx.showModal({
        title: '请先登录',
        content: '',
        showCancel:false,
        success:function(res){
          if(res.confirm)
          wx.switchTab({
            url: '../../pages/my/my',
          })
        }
      })

    }



    var that=this;
    wx.request({
      url: app.apiUrl+'calendar',
      method:"GET",
      data:{
        openid:app.openid
      },
      success:function(e){
        console.log(e.data)
        that.setData({
       selected:e.data.data,
       flag:e.data.flag
    })

      }
    })




    // var arr=[];
    // for(var i=1;i<5;i++){
    //   var obj=new Object();
    //   obj.date='2020-6-'+i;
    //   arr.push(obj)
    // }
    // this.setData({
    //   selected:arr
    // })
     
  },
  /**
  * 日历是否被打开
  */
  bindselect(e) {
    console.log(e.detail.ischeck)
    e.detail.ischeck=true
  },
  /**
   * 获取选择日期
   */
  bindgetdate(e) {
    let time = e.detail;
    console.log(time)

  }
})