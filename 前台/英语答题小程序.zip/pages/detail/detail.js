// pages/detail/detail.js
var app = getApp().globalData;
Page({

  /**
   * 页面的初始数据
   */
  data: {
   index:0,
   questionList:[],
   msg:"",
   selected:""
  },
 detailData:function(url,id,openid){
  wx.request({
    url: url,
    method:'GET',
    data:{
      "id":id,
      "openid":openid
    },
    success:function(e){

    }
  })
 },
 question:function(e){
   console.log(this.data.questionList[0])
   var that=this;
   if(e.target.dataset.option=='A'){
    if(this.data.questionList[this.data.index].questionT==e.target.dataset.option){
      this.setData({
        btn1:"success",
        msg:that.data.questionList[that.data.index].questionmessage
      })
      this.detailData(app.apiUrl+'addRight',this.data.questionList[this.data.index].id,app.openid)
   }else{
    this.setData({
      btn1:"error",
      msg:that.data.questionList[that.data.index].questionmessage
    })
    this.detailData(app.apiUrl+'addWrong',this.data.questionList[this.data.index].id,app.openid)
   }
   }
else{
  if(this.data.questionList[this.data.index].questionT==e.target.dataset.option){
    this.setData({
      btn2:"success",
      msg:that.data.questionList[that.data.index].questionmessage
    })
    this.detailData(app.apiUrl+'addRight',this.data.questionList[this.data.index].id,app.openid)
 }else{
  this.setData({
    btn2:"error",
    msg:that.data.questionList[that.data.index].questionmessage
  })
  this.detailData(app.apiUrl+'addWrong',this.data.questionList[this.data.index].id,app.openid)
 }
 }
 },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      for(var i=0;i<(JSON.parse(options.question)[0]).length;i++)
           this.data.questionList.push(JSON.parse(options.question)[0][i])
      console.log(typeof this.data.questionList[0])
      console.log(this.data.index)
      this.setData({
        item:this.data.questionList[this.data.index]
      })
  },
  next:function(){
    this.setData({
      btn1:"",
      btn2:"",
      msg:""
    })
    this.data.index++;
    setTimeout(function () {
      //要延时执行的代码
     }, 1500) //延迟时间 这里是1秒
    this.setData({
      item:this.data.questionList[this.data.index]
      //msg:""
    })
    console.log(this.data.index)
    if(this.data.index>=this.data.questionList.length){
      wx.showModal({
        title: '该类别已经答完，请选择其他题目',
        content: '',
        showCancel:false,
        success:function(res){
          if(res.confirm)
          wx.switchTab({
            url: '../../pages/index/index',
          })
        }
      })
  }


  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log(564564)
    console.log(app.userInfo)
    if(app.userInfo==""){
      wx.showModal({
        title: '请先登录',
        content: '',
        showCancel:false,
        success:function(res){
          if(res.confirm)
          wx.switchTab({
            url: '../../pages/my/my',
          })
        }
      })

    }


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },
  getRadio:function(e){
    this.data.selected=e.detail.currentKey
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})